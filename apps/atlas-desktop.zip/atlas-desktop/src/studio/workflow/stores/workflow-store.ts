// Atlas Workflow Studio - Workflow Canvas Store
// Central Zustand store for the visual node canvas
// RFC-0302, RFC-0303, RFC-0307 compliant

import { create } from 'zustand';
import { subscribeWithSelector } from 'zustand/middleware';
import type {
  WorkflowNodeData,
  WorkflowEdgeData,
  WorkflowDefinition,
  WorkflowVariable,
  CanvasTransform,
  SelectionState,
  ValidationResult,
  NodeExecutionState,
  ValidationState,
  NodeCategory,
} from '../types';
import { NODE_CATEGORIES } from '../types/node-categories';

// ---------------------------------------------------------------------------
// Internal node representation (React Flow compatible)
// ---------------------------------------------------------------------------

export interface WorkflowGraphNode {
  id: string;
  type: string;
  label: string;
  description?: string;
  category: NodeCategory;
  inputs: Array<{ id: string; name: string; type: string; multiple?: boolean; dynamic?: boolean }>;
  outputs: Array<{ id: string; name: string; type: string; multiple?: boolean; dynamic?: boolean }>;
  parameters: Record<string, unknown>;
  priority?: number;
  timeout?: string;
  retryPolicy?: unknown;
  icon?: string;
  executionState?: NodeExecutionState;
  validationState?: ValidationState;
  statusMessage?: string;
  documentationUrl?: string;
  capabilities?: string[];
  version?: string;
  x: number;
  y: number;
}

export interface WorkflowGraphEdge {
  id: string;
  source: string;
  target: string;
  edgeType: string;
  condition?: string;
  transformation?: string;
  cardinality?: string;
}

// ---------------------------------------------------------------------------
// Undo/Redo stack entry
// ---------------------------------------------------------------------------

interface HistoryEntry {
  nodes: WorkflowGraphNode[];
  edges: WorkflowGraphEdge[];
  variables: WorkflowVariable[];
  timestamp: number;
}

// ---------------------------------------------------------------------------
// Store state
// ---------------------------------------------------------------------------

export interface WorkflowCanvasState {
  // Graph data
  nodes: WorkflowGraphNode[];
  edges: WorkflowGraphEdge[];
  variables: WorkflowVariable[];

  // Canvas transform
  transform: CanvasTransform;

  // Selection
  selection: SelectionState;

  // Validation results
  validationResults: ValidationResult[];

  // Undo/redo history
  history: HistoryEntry[];
  historyIndex: number;

  // Workflow definition reference
  workflowId: string;
  workflowName: string;
  workflowVersion: string;

  // Computed
  selectedNodeIds: string[];
  selectedEdges: string[];

  // Actions
  setNodes: (nodes: WorkflowGraphNode[]) => void;
  addNode: (node: WorkflowGraphNode) => void;
  updateNode: (id: string, partial: Partial<WorkflowGraphNode>) => void;
  removeNode: (id: string) => void;
  duplicateNode: (id: string) => void;
  setEdges: (edges: WorkflowGraphEdge[]) => void;
  addEdge: (edge: WorkflowGraphEdge) => void;
  removeEdge: (id: string) => void;
  setTransform: (transform: CanvasTransform) => void;
  selectNode: (id: string, multi?: boolean) => void;
  selectEdge: (id: string, multi?: boolean) => void;
  deselectAll: () => void;
  selectAll: () => void;
  setValidationResults: (results: ValidationResult[]) => void;
  setWorkflowInfo: (id: string, name: string, version: string) => void;
  setCanvasPosition: (x: number, y: number, zoom?: number) => void;
  updateNodeExecutionState: (nodeId: string, state: NodeExecutionState) => void;
  updateNodeValidationState: (nodeId: string, state: ValidationState) => void;
  moveSelectedNodes: (dx: number, dy: number) => void;
  panCanvas: (dx: number, dy: number) => void;
  zoomCanvas: (delta: number) => void;
  undo: () => void;
  redo: () => void;
  clearHistory: () => void;
  addVariable: (variable: WorkflowVariable) => void;
  updateVariable: (id: string, updates: Partial<WorkflowVariable>) => void;
  removeVariable: (id: string) => void;
  setVariables: (variables: WorkflowVariable[]) => void;
  loadFromDefinition: (def: WorkflowDefinition) => void;
  exportToDefinition: () => WorkflowDefinition;
  resetCanvas: () => void;
}

const DEFAULT_TRANSFORM: CanvasTransform = { x: 0, y: 0, zoom: 1 };

function createInitialHistory(): HistoryEntry {
  return { nodes: [], edges: [], variables: [], timestamp: Date.now() };
}

export const useWorkflowStore = create<WorkflowCanvasState>()(
  subscribeWithSelector((set, get) => ({
    // Initial state
    nodes: [],
    edges: [],
    variables: [],
    transform: DEFAULT_TRANSFORM,
    selection: {
      selectedNodeIds: new Set(),
      selectedEdgeIds: new Set(),
    },
    validationResults: [],
    history: [createInitialHistory()],
    historyIndex: 0,
    workflowId: '',
    workflowName: '',
    workflowVersion: '1.0.0',

    // Computed getters
    get selectedNodeIds() {
      return Array.from(get().selection.selectedNodeIds);
    },
    get selectedEdges() {
      return Array.from(get().selection.selectedEdgeIds);
    },

    // -----------------------------------------------------------------------
    // Node operations
    // -----------------------------------------------------------------------
    setNodes: (nodes) => {
      set({ nodes });
      get().pushHistory();
    },

    addNode: (node) => {
      set((state) => ({ nodes: [...state.nodes, node] }));
      get().pushHistory();
    },

    updateNode: (id, partial) => {
      set((state) => ({
        nodes: state.nodes.map((n) => (n.id === id ? { ...n, ...partial } : n)),
      }));
    },

    removeNode: (id) => {
      set((state) => ({
        nodes: state.nodes.filter((n) => n.id !== id),
        edges: state.edges.filter((e) => e.source !== id && e.target !== id),
        selection: {
          ...state.selection,
          selectedNodeIds: new Set(
            Array.from(state.selection.selectedNodeIds).filter((nId) => nId !== id)
          ),
        },
      }));
      get().pushHistory();
    },

    duplicateNode: (id) => {
      const source = get().nodes.find((n) => n.id === id);
      if (!source) return;
      const newId = `${source.id}_dup_${Date.now()}`;
      const newNode: WorkflowGraphNode = {
        ...source,
        id: newId,
        label: `${source.label} (copy)`, 
        x: source.x + 40,
        y: source.y + 40,
      };
      set((state) => ({
        nodes: [...state.nodes, newNode],
        selection: {
          ...state.selection,
          selectedNodeIds: new Set([newId]),
        },
      }));
      get().pushHistory();
    },

    // -----------------------------------------------------------------------
    // Edge operations
    // -----------------------------------------------------------------------
    setEdges: (edges) => {
      set({ edges });
      get().pushHistory();
    },

    addEdge: (edge) => {
      set((state) => ({ edges: [...state.edges, edge] }));
      get().pushHistory();
    },

    removeEdge: (id) => {
      set((state) => ({
        edges: state.edges.filter((e) => e.id !== id),
        selection: {
          ...state.selection,
          selectedEdgeIds: new Set(
            Array.from(state.selection.selectedEdgeIds).filter((eId) => eId !== id)
          ),
        },
      }));
      get().pushHistory();
    },

    // -----------------------------------------------------------------------
    // Canvas transform
    // -----------------------------------------------------------------------
    setTransform: (transform) => set({ transform }),

    setCanvasPosition: (x, y, zoom) =>
      set((state) => ({
        transform: {
          x,
          y,
          zoom: zoom ?? state.transform.zoom,
        },
      })),

    panCanvas: (dx, dy) =>
      set((state) => ({
        transform: {
          ...state.transform,
          x: state.transform.x + dx,
          y: state.transform.y + dy,
        },
      })),

    zoomCanvas: (delta) =>
      set((state) => {
        const newZoom = Math.max(0.1, Math.min(5, state.transform.zoom + delta));
        return { transform: { ...state.transform, zoom: newZoom } };
      }),

    // -----------------------------------------------------------------------
    // Selection
    // -----------------------------------------------------------------------
    selectNode: (id, multi = false) => {
      set((state) => {
        const ids = new Set(state.selection.selectedNodeIds);
        if (multi) {
          ids.has(id) ? ids.delete(id) : ids.add(id);
        } else {
          ids.clear();
          ids.add(id);
        }
        return { selection: { ...state.selection, selectedNodeIds: ids } };
      });
    },

    selectEdge: (id, multi = false) => {
      set((state) => {
        const ids = new Set(state.selection.selectedEdgeIds);
        if (multi) {
          ids.has(id) ? ids.delete(id) : ids.add(id);
        } else {
          ids.clear();
          ids.add(id);
        }
        return { selection: { ...state.selection, selectedEdgeIds: ids } };
      });
    },

    deselectAll: () =>
      set({
        selection: {
          selectedNodeIds: new Set(),
          selectedEdgeIds: new Set(),
        },
      }),

    selectAll: () =>
      set((state) => ({
        selection: {
          selectedNodeIds: new Set(state.nodes.map((n) => n.id)),
          selectedEdgeIds: new Set(state.edges.map((e) => e.id)),
        },
      })),

    // -----------------------------------------------------------------------
    // Move selected nodes
    // -----------------------------------------------------------------------
    moveSelectedNodes: (dx, dy) => {
      set((state) => ({
        nodes: state.nodes.map((n) => {
          if (state.selection.selectedNodeIds.has(n.id)) {
            return { ...n, x: n.x + dx, y: n.y + dy };
          }
          return n;
        }),
      }));
    },

    // -----------------------------------------------------------------------
    // Validation
    // -----------------------------------------------------------------------
    setValidationResults: (results) => set({ validationResults: results }),

    updateNodeExecutionState: (nodeId, state) =>
      set((s) => ({
        nodes: s.nodes.map((n) =>
          n.id === nodeId ? { ...n, executionState: state } : n
        ),
      })),

    updateNodeValidationState: (nodeId, state) =>
      set((s) => ({
        nodes: s.nodes.map((n) =>
          n.id === nodeId ? { ...n, validationState: state } : n
        ),
      })),

    // -----------------------------------------------------------------------
    // Workflow info
    // -----------------------------------------------------------------------
    setWorkflowInfo: (id, name, version) =>
      set({ workflowId: id, workflowName: name, workflowVersion: version }),

    // -----------------------------------------------------------------------
    // Variable management
    // -----------------------------------------------------------------------
    addVariable: (variable) =>
      set((state) => ({ variables: [...state.variables, variable] })),

    updateVariable: (id, updates) =>
      set((state) => ({
        variables: state.variables.map((v) =>
          v.id === id ? { ...v, ...updates } : v
        ),
      })),

    removeVariable: (id) =>
      set((state) => ({
        variables: state.variables.filter((v) => v.id !== id),
      })),

    setVariables: (variables) => set({ variables }),

    // -----------------------------------------------------------------------
    // Import / Export
    // -----------------------------------------------------------------------
    loadFromDefinition: (def) => {
      const nodes: WorkflowGraphNode[] = def.nodes.map((n, i) => ({
        id: n.id,
        type: n.type,
        label: n.label || n.id,
        description: n.description,
        category: n.category || 'core',
        inputs: n.inputs || [],
        outputs: n.outputs || [],
        parameters: n.parameters || {},
        priority: n.priority,
        timeout: n.timeout,
        retryPolicy: n.retry,
        icon: n.icon,
        executionState: 'pending' as NodeExecutionState,
        validationState: 'unchecked' as ValidationState,
        statusMessage: '',
        documentationUrl: n.documentationUrl,
        capabilities: n.capabilities,
        version: n.version,
        x: 100 + (i % 5) * 220,
        y: 100 + Math.floor(i / 5) * 160,
      }));
      const edges: WorkflowGraphEdge[] = def.edges.map((e) => ({
        id: e.id,
        source: e.source,
        target: e.target,
        edgeType: e.edgeType,
        condition: e.condition,
        transformation: e.transformation,
        cardinality: e.cardinality,
      }));
      set({
        nodes,
        edges,
        variables: def.variables || [],
        workflowId: def.id,
        workflowName: def.name,
        workflowVersion: def.version,
      });
      get().pushHistory();
    },

    exportToDefinition: (): WorkflowDefinition => {
      const state = get();
      return {
        id: state.workflowId,
        version: state.workflowVersion,
        name: state.workflowName,
        nodes: state.nodes.map((n) => ({
          id: n.id,
          type: n.type,
          label: n.label,
          description: n.description,
          category: n.category,
          inputs: n.inputs,
          outputs: n.outputs,
          parameters: n.parameters,
          priority: n.priority,
          timeout: n.timeout,
          retry: n.retryPolicy,
          icon: n.icon,
          documentationUrl: n.documentationUrl,
          capabilities: n.capabilities,
          version: n.version,
        })),
        edges: state.edges.map((e) => ({
          id: e.id,
          source: e.source,
          target: e.target,
          edgeType: e.edgeType,
          condition: e.condition,
          transformation: e.transformation,
          cardinality: e.cardinality,
        })),
        variables: state.variables,
        parameters: {},
        metadata: {
          createdAt: Date.now(),
          updatedAt: Date.now(),
          tags: [],
        },
      };
    },

    // -----------------------------------------------------------------------
    // Undo / Redo
    // -----------------------------------------------------------------------
    pushHistory: () => {
      const state = get();
      const snapshot: HistoryEntry = {
        nodes: [...state.nodes],
        edges: [...state.edges],
        variables: [...state.variables],
        timestamp: Date.now(),
      };
      const newHistory = state.history.slice(0, state.historyIndex + 1);
      newHistory.push(snapshot);
      // Keep history manageable
      if (newHistory.length > 100) {
        newHistory.shift();
      }
      set({ history: newHistory, historyIndex: newHistory.length - 1 });
    },

    undo: () => {
      const state = get();
      if (state.historyIndex <= 0) return;
      const prev = state.history[state.historyIndex - 1];
      set({
        nodes: prev.nodes,
        edges: prev.edges,
        variables: prev.variables,
        historyIndex: state.historyIndex - 1,
        selection: { selectedNodeIds: new Set(), selectedEdgeIds: new Set() },
      });
    },

    redo: () => {
      const state = get();
      if (state.historyIndex >= state.history.length - 1) return;
      const next = state.history[state.historyIndex + 1];
      set({
        nodes: next.nodes,
        edges: next.edges,
        variables: next.variables,
        historyIndex: state.historyIndex + 1,
        selection: { selectedNodeIds: new Set(), selectedEdgeIds: new Set() },
      });
    },

    clearHistory: () => {
      set({ history: [createInitialHistory()], historyIndex: 0 });
    },

    // -----------------------------------------------------------------------
    // Reset
    // -----------------------------------------------------------------------
    resetCanvas: () => {
      set({
        nodes: [],
        edges: [],
        variables: [],
        transform: DEFAULT_TRANSFORM,
        selection: { selectedNodeIds: new Set(), selectedEdgeIds: new Set() },
        validationResults: [],
        history: [createInitialHistory()],
        historyIndex: 0,
        workflowId: '',
        workflowName: '',
        workflowVersion: '1.0.0',
      });
    },
  }))
);

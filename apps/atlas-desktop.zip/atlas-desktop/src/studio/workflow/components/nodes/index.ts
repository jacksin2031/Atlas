﻿// Atlas Workflow Studio - Node Components Index
export { WorkflowNode } from './workflow-node';
export { EntryNode } from './entry-node';
export { ExitNode } from './exit-node';
export { CompositeNode } from './composite-node';

// Node type registry for React Flow
import type { Node } from '@xyflow/react';
import type { WorkflowGraphNode } from '../stores/workflow-store';

export const NODE_TYPES = {
  workflow: WorkflowNode,
  entry: EntryNode,
  exit: ExitNode,
  composite: CompositeNode,
};

export type NodeTypeName = keyof typeof NODE_TYPES;

// Default node type mapping
export function getNodeTypeName(data: Node['data']): NodeTypeName {
  if (data.type === 'entry') return 'entry';
  if (data.type === 'exit') return 'exit';
  if (data.type === 'composite') return 'composite';
  return 'workflow';
}
